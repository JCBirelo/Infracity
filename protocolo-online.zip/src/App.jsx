import React from 'react';

export default function App() {
  return (
    <div>
      <h1>Portal de Protocolos</h1>
      <p>Seu sistema está online e funcional. Continue a integração.</p>
    </div>
  );
}
